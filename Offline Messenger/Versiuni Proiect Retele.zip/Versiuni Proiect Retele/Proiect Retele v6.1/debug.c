#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <dirent.h>





int search(char account[100])
{
char entry[100],ch;
int i,end=1;
//for(int j=0;comanda[j+5]!='\0';j++)
  //      comanda[j]=comanda[j+6];
int fd= open("accounts",O_RDONLY);
do
{
        i=0;
	bzero(entry,100);
        end=read(fd,&ch,1);
        while((ch!='|')&&(end))
        {//printf("read %c",ch); fflush (stdout);
        entry[i]=ch;
        i++;
	end=read(fd,&ch,1);
        }
        while((ch!='\n')&&(end))
                read(fd,&ch,1);


}while((end)&&(strcmp(entry,account)));

return(strcmp(entry,account)==0);
close(fd);

}


int main()
{
int a;
a=strcmp("password","psasword");
printf("%d\n",a);
printf("%d","a");




}


